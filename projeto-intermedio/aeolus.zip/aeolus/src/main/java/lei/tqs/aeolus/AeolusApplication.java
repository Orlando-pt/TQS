package lei.tqs.aeolus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AeolusApplication {

	public static void main(String[] args) {
		SpringApplication.run(AeolusApplication.class, args);
	}

}
