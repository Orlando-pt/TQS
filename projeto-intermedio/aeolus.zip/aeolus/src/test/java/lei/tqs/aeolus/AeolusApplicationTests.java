package lei.tqs.aeolus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AeolusApplicationTests {

	@Test
	void contextLoads() {
	}

}
